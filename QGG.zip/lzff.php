<?php
error_reporting(0);
header('content-type:application/json;charset=utf-8');
header('Connection: Keep-Alive');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: true');
header("access-control-allow-methods: GET, POST, PUT, DELETE, HEAD, OPTIONS");
header("access-control-allow-headers: Accept,Authorization,Cache-Control,Content-Type,DNT,If-Modified-Since,Keep-Alive,Origin,User-Agent,X-Mx-ReqToken,X-Requested-With");
define('REDIS_HOST', '127.0.0.1'); //只能是默认密码为空，修改过请勿开启使用
define('REDIS_PORT', 6379);
define('REDIS_TIMEOUT', 1);
require_once(__DIR__ . '/lzff_GX_B.php');
include(__DIR__ . '/admin/data.php');
$web_time = microtime(true);
$webApi = domain();
RSNE($lele, basename(__FILE__));
$Vtche = $_GET['Vtche'];
$d = isset($_GET['d']) ? intval($_GET['d']) : null;
if (isset($Vtche)) {
    $password = '123456'; //（默认密码自行修改）
    Vtche($Vtche, $password, $d);
}
if ($_GET['url'] == '') {
    die(Html('请输入URL网址！'));
}
$Info = '技术群:200702731';
PRST($lele, $vurl, $ep_file, $webApi, $url, $Origin, $GXGG, $Info);


/* 
=================================（请仔细阅读）=================================
本项目由 QQ:424603904 Feng 开发，已经稳定运行第3年。
因不确定因素，使用此代码造成的任何问题，作者不承担任何责任。（包括侵权、法律责任...等）
代码新建一个站点放在一级目录下、一键部署，自动生成多个文件。（详细看图片教程）不支持二级目录
网站授权，部分代码混淆处理防止不守规则的人倒卖泛滥。（谢谢理解后购买）
不包远程搭建设置（需要自己动手去对接）
第三方对接（网页、app、计费）群内各位站长交流。开发者不做站
php版本必须使用7.3，其他可能报错或代码无法运行。
某些原始链接打不开的。（查看末尾注解↓）
建议使用国内ip服务器（某些IP运营商需要备案才能使用，这个需要自己检测，比如：江苏、襄阳、北京...等） 
某些资源站已经屏蔽海外和香港ip服务器。
有域名优先使用域名搭建，以后换服务器不需要从新授权。（https更好，因为某些对接需要验证证书）
如何发现Vtche目录下无法生成m3u8文件或创建文件夹，请赋予Vtche目录写入权限，并将Vtche目录的权限设为777
接口调用例如：  http://localhost/lzff.php?url=https://hd.lz-cdn18.com/20230529/2960_c6cec6dd/index.m3u8
代码精简，运行效率更高，更快，移除广告更精准 
以下代码只支持去插播广告，跑马灯和水印无法去除。
目前支持多达10几个平台，维护不易。很多站长都在使用。
当前网站未授权或授权码错误！请联系开发者！
更换授权码需要提供旧的授权码和新搭建的网站。

切记！！！自行备份好授权码，遗失不补，开发者和代理商没有义务帮保存授权码。
发现无法去除干净或他们站长更新规则，把链接发群里，有时间再更新。
授权码变更如下：
365天 2次
500天 3次
1000天 7次
2000天 2次/年
其他卡不给予更换，变更需要提供新的服务器地址或域名，以及旧的授权码。
（端口、域名、ip、嵌套cdn）变化都算更换。
如果域名端口不变更换切换到新服务器旧的授权码不受影响。

旗下客户比较多，调用过大，建议购买多个授权码，多台服务器轮询调用，不然容易导致IP被封禁。
切记！！！无缘无故退群者，将视为放弃。不在补位进群。（需要重新后买授权码）
发现好用的直链资源站，可以联系我收录更新。

- 核心技术
1.一键部署，安装简单。
2.计划定时每2小时，校队远程文件自动更新。
3.部分网站采用自动检测广告自动更新等。
4.添加自定义IP授权访问和当前ip查询。
5.采用并发机制，提升网站响应速度。

- 部分功能使用说明
1.切记一定要挂起定时访问 GX.php 文件，否则无法更新到最新版本，导致去广告失效。

2.更新说明：
http://你的域名/GX.php?gx   普通更新，不删除缓存。
http://你的域名/GX.php?gx0  普通更新,有更新时才删除近3天缓存
http://你的域名/GX.php?gx1  强制更新部分，不删除缓存。
http://你的域名/GX.php?gx2  强制更新全部，删除近3天缓存
http://你的域名/GX.php?gx3  强制更新全部，不删除缓存。

3.一键清空全部缓存命令：http://你的域名/lzff.php?Vtche=123456（默认密码自行修改，可自定义删除天数，查看下面注解）
4.lzff.php 调用文件可以重命名，其他切勿改名，否则无法正常运行。
5.查询当前IP地址 http://你的域名/lzff.php?ip
6.开启IP授权访问接口、时效链接，http://你的域名/admin （默认 账号：admin 密码：123456）config.php请修改
7.未授权IP防盗触发，请自行更换提示信息。
8.统计当日接口被访问次数。
9.添加缓存重定向链接。
10.添加Redis缓存
11.更新lzff.php防盗功能，在后台自定义设置重命名 确定修改，第一次访问 后台 访问自定义接口。

================================（以免不必要麻烦）================================
量子：http://23.224.101.30  采集：https://cj.lziapi.com/api.php/provide/vod/from/lzm3u8/?ac=list
如意：https://www.ryzy5.tv 采集：https://cj.rycjapi.com/api.php/provide/vod/from/rym3u8/?ac=list（停更：因规则变动太频繁，某些每天都在变）
非凡：https://cj.ffzyapi.com  采集：http://cj.ffzyapi.com/api.php/provide/vod/from/ffm3u8/?ac=list
暴风：https://bfzy3.tv 采集：http://by.bfzyapi.com/api.php/provide/vod/from/bfzym3u8/?ac=list
优质：https://yzzy.tv  采集：https://api.yzzy-api.com/inc/api_mac10.php/provide/vod/?ac=list
魔都：https://moduzy2.com  采集：https://www.mdzyapi.com/api.php/provide/vod/from/modum3u8/?ac=list
爱坤：https://ikunzy.vip  采集：https://ikunzy.vip/api.php/provide/vod/?ac=list
360资源：https://360zy.com  采集：https://360zy.com/api.php/provide/vod/from/360zy/?ac=list
U酷：http://www.ukuzy.com 采集：https://api.ukuapi.com/api.php/provide/vod/from/ukm3u8/?ac=list
天涯：https://tyyszy.com 采集：https://tyyszyapi.com/api.php/provide/vod/from/tym3u8?ac=list
豆瓣：https://dbzy.tv 采集：https://caiji.dbzy.tv/api.php/provide/vod/from/dbm3u8/?ac=list
天堂:http://dyttzyw.com 采集：http://caiji.dyttzyapi.com/api.php/provide/vod/from/dyttm3u8/?ac=list （个别链接压缩其他资源站，插播都没去，直接压进去）
猫眼:https://www.maoyanzy.com 采集：https://api.maoyanapi.top/api.php/provide/vod/from/mym3u8/?ac=list （压缩其他资源站，插播都没去，直接压进去）

多合一 （有些资源比老太婆走路还慢），根据需求使用。
索尼：https://suonizy.cc  采集：https://suoniapi.com/api.php/provide/vod/from/snm3u8/?ac=list
最大：https://zuidazy.me  采集：https://api.zuidapi.com/api.php/provide/vod/from/zuidam3u8/?ac=list
OK资源：https://okzyw.cc  采集：https://api.okzyw.net/api.php/provide/vod/?ac=list
牛牛：https://www.niuniuzy.org 采集：https://api.niuniuzy.me/api.php/provide/vod/from/nnm3u8/?ac=list
快车：https://kuaichezy.vip 采集：https://caiji.kuaichezy.org/api.php/provide/vod/?ac=list
闪电：https://shandianzy.com 采集：https://xsd.sdzyapi.com/api.php/provide/vod/from/sdm3u8/?ac=list
丫丫（鸭鸭）：https://yayazy.com  采集：https://cj.yayazy.net/api.php/provide/vod/from/yym3u8/?ac=list
无尽：https://www.wujinzy.net  采集：https://api.wujinapi.me/api.php/provide/vod/from/wjm3u8/?ac=list
爱奇艺：https://www.iqiyizy.com  采集：https://www.iqiyizyapi.com/api.php/provide/vod/?ac=list

大水印同类 （无插播，只缓存去除片头，中间跑马灯、大水印没去）有些资源比老太婆走路还慢，根据需求使用。
新浪：https://www.xinlangzy.net  采集：https://api.xinlangapi.com/xinlangapi.php/provide/vod/from/xlm3u8/?ac=list（新浪和速播链接相同）
速播：https://www.subozy.com   采集：https://subocj.com/api.php/provide/vod/from/subm3u8/at/json（新浪和速播链接相同）
红牛：https://hongniuzy.net  采集：https://www.hongniuzy2.com/api.php/provide/vod/from/hnm3u8/?ac=list
极速：http://www.jisuzy.com  采集：https://jszyapi.com/api.php/provide/vod/from/jsm3u8/?ac=list
豪华：https://hhzyapi.com  采集：https://hhzyapi.com/api.php/provide/vod/from/hhm3u8/?ac=list
光速：https://guangsuzy.net 采集：https://api.guangsuapi.com/api.php/provide/vod/from/gsm3u8/?ac=list
淘片：https://www.taopianzy.com/index.html 采集：https://taopianapi.com/cjapi/mc10/vod/json/m3u8.html
卧龙：https://wolongzy.tv  采集：https://collect.wolongzy.cc/api.php/provide/vod/?ac=list
百度：https://api.apibdzy.com/ 采集：https://api.apibdzy.com/api.php/provide/vod/from/dbm3u8/?ac=list（地区限制，有些无法打开）
茅台：https://mtzy.me 采集：https://caiji.maotaizy.cc/api.php/provide/vod/from/mtm3u8/?ac=list
樱花：https://yhzy.men/ 采集：https://m3u8.apiyhzy.com/api.php/provide/vod/?ac=list
虎牙：https://www.huyaapi.com 采集：https://www.huyaapi.com/api.php/provide/vod/from/hym3u8/at/json
旺旺短剧：https://www.wwzy.tv 采集：https://api.wwzy.tv/api.php/provide/vod/?ac=list（地区限制）
金鹰：https://jinyingzy.com 采集：https://jyzyapi.com/provide/vod/from/jinyingm3u8/at/json
魔爪：https://mzzy.me 采集：https://mozhuazy.com/api.php/provide/vod/from/mzm3u8?ac=list
========================================================================================

一些常见问题说明

一、很多人问为什么我当前网络正常访问，放到服务器就不行。
答：
1.当前网络是国内的宽带 → 资源站的链接。（A-C）
2.放到服务器IP检测是 你服务器网络 → 资源站的链接.(B-C)
3.俩者是处于不同网络环境 

二、缓存后调用会不会很吃服务器宽带？
答：不会 因为没写反代，我们访问的是m3u8缓存的文件一个文件才几KB，访问文件后走的就是 你当前网络到资源站的图床的速度。（与你服务器宽带没有毛钱关系）

三、为什么缓存了m3u8确无法播放？
答：可能这个资源没有完成切片或资源站图床有问题。

四、服务器IP被屏蔽怎么办？
答：
1.联系资源站站长解封。
2.域名解析到其他服务器。
3.更换服务器。

五、为什么网站突然白屏502、404.....之类的。
1.创建一个1.php文件，写入echo 'ok';然后访问是否正常。（有些txt文件正常访问，php不行。说明面板服务有问题）
2.查看当前服务器是否被CC攻击。
3.重启服务器面板或重启服务器。
4.终极方法，重新安装宝塔或更换服务器。
5.运营商问题。

六、购买时解析正常，过段时间大部分解析都失败。
1.请求太频繁被资源站封   
2.资源站CND域名不支持你服务器网络

*/